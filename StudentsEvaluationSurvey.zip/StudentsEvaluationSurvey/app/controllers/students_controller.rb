class StudentsController < ApplicationController
	def index
		@students = Student.where(department_id: current_teacher.department_id)
	end

	def show
		
	end

end
