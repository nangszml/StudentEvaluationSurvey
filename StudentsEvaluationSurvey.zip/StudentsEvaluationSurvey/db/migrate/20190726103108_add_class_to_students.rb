class AddClassToStudents < ActiveRecord::Migration[5.2]
  def change
  	add_column :students, :class, :string
  end
end
