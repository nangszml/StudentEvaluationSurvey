require 'test_helper'

class SurveyFormTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
