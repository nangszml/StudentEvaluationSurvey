require 'test_helper'

class SurveyResultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
